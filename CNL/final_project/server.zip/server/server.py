import http.server
import http.cookies
import socketserver
import subprocess
import sys
from urllib.parse import unquote_plus

assert(len(sys.argv)==2)
PORT=int(sys.argv[1])

class handler(http.server.SimpleHTTPRequestHandler):
	def do_GET(self):
		self.path='/index.html'
		return http.server.SimpleHTTPRequestHandler.do_GET(self)

with socketserver.TCPServer(("", PORT), handler) as httpd:
	print("Server started at localhost:"+str(PORT))
	httpd.serve_forever()

