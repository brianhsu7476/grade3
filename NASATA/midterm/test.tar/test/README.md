The usage of ```./sample.sh``` and ```./check.sh``` is the same as in HW2.
That is, put your ```script.sh``` in this directory and execute ```./sample.sh```. The output will be in ```output/```, and the sample output is in ```sample_output/```. You can execute ```./check.sh``` to check if your output is correct.
