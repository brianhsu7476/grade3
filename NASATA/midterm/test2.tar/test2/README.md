Run ```./check.sh <script_name>```
A task i is correct iff all ```i-j.txt``` are Accepted.

Score:
Task 1: 4pts
Task 2: 4pts
Task 3: 2pts
Task 4: 2pts
